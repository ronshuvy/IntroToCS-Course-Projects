
Hello !

We have added the following features to our game :
1. Buy extra time (before clock's run out) -
30 seconds for 10 points
Purchase is only available when the player has more than 20 points.

2. List of wrong words attempts entered by the player.

Hope you'll enjoy our game !
Elad & Ron.